import { Component, ViewChild } from '@angular/core';
import { Platform, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';
import { PatientResetPage } from '../pages/patient-reset/patient-reset';
import { PatientTabsPage } from '../pages/patient-tabs/patient-tabs'
import { ViewerTabsPage } from '../pages/viewer-tabs/viewer-tabs'
import { Storage } from '@ionic/storage';
import { Deeplinks } from '@ionic-native/deeplinks';
import { platformBrowser } from '@angular/platform-browser';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {

  @ViewChild(Nav) nav: Nav;

  currentUser: any;
  rootPage: any;

  constructor(private deeplinks: Deeplinks, platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, private storage: Storage) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
      this.storage.ready().then(() => {
        //this.storage.remove('token');
        this.storage.get('token').then((val) => {
          this.currentUser = val;
          if (this.currentUser) {
            if (this.currentUser.type == "Viewer") {
              this.rootPage = ViewerTabsPage;
            } else {
              this.rootPage = PatientTabsPage;
            }
          } else {
            this.rootPage = LoginPage;
          }
        });
      });
      // deeplinks.route({
      //   // '/patient': (() => {
      //   //   console.log('patient')
      //   // }),
      //   // '/patient1': (() => {
      //   //   this.rootPage = PatientResetPage;
      //   // }),
      //   // '/pp': PatientResetPage,
      //   // '/': (() => {
      //   //   console.log('/')
      //   // }),
      //   // '': (() => {
      //   //   console.log('nothing')
      //   // })
      // }).subscribe((match) => {
      //   // match.$route - the route we matched, which is the matched entry from the arguments to route()
      //   // match.$args - the args passed in the link
      //   // match.$link - the full link data
      //   alert(match);
      //   console.log('Successfully matched route', match);
      // }, (nomatch) => {
      //   // nomatch.$link - the full link data
      //   console.error('Got a deeplink that didn\'t match', nomatch);
      // });

    });
  }


}
